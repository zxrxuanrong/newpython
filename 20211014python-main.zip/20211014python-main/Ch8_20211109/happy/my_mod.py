def happy_python():
    print("Happy Python!!")