class test1:
    def __init__(self):
        print("Create")
def fun1():
    print("func 1")

# 希望以下功能是在 單獨執行modu.py時候 發生
# import 不要發生
print("Test Modu")   